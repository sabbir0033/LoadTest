/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 91.12903225806451, "KoPercent": 8.870967741935484};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.184375, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.1, 500, 1500, "http://159.89.38.11/-21"], "isController": false}, {"data": [0.0, 500, 1500, "http://159.89.38.11/login/submit"], "isController": false}, {"data": [0.05, 500, 1500, "http://159.89.38.11/-22"], "isController": false}, {"data": [0.025, 500, 1500, "http://159.89.38.11/-20"], "isController": false}, {"data": [0.0, 500, 1500, "Test"], "isController": true}, {"data": [0.0, 500, 1500, "http://159.89.38.11/chart/data"], "isController": false}, {"data": [0.275, 500, 1500, "http://159.89.38.11/-5"], "isController": false}, {"data": [0.025, 500, 1500, "http://159.89.38.11/-6"], "isController": false}, {"data": [0.525, 500, 1500, "http://159.89.38.11/-7"], "isController": false}, {"data": [0.275, 500, 1500, "http://159.89.38.11/-8"], "isController": false}, {"data": [0.0, 500, 1500, "http://159.89.38.11/-9"], "isController": false}, {"data": [0.0, 500, 1500, "http://159.89.38.11/-12"], "isController": false}, {"data": [0.05, 500, 1500, "http://159.89.38.11/-13"], "isController": false}, {"data": [0.05, 500, 1500, "http://159.89.38.11/-10"], "isController": false}, {"data": [0.275, 500, 1500, "http://159.89.38.11/-0"], "isController": false}, {"data": [0.125, 500, 1500, "http://159.89.38.11/-11"], "isController": false}, {"data": [0.5333333333333333, 500, 1500, "http://159.89.38.11/-1"], "isController": false}, {"data": [0.725, 500, 1500, "http://159.89.38.11/-2"], "isController": false}, {"data": [0.075, 500, 1500, "http://159.89.38.11/-3"], "isController": false}, {"data": [0.1, 500, 1500, "http://159.89.38.11/-4"], "isController": false}, {"data": [0.0, 500, 1500, "http://159.89.38.11/"], "isController": false}, {"data": [0.0, 500, 1500, "http://159.89.38.11/-18"], "isController": false}, {"data": [0.05, 500, 1500, "http://159.89.38.11/-19"], "isController": false}, {"data": [0.175, 500, 1500, "http://159.89.38.11/-16"], "isController": false}, {"data": [0.1, 500, 1500, "http://159.89.38.11/-17"], "isController": false}, {"data": [0.0, 500, 1500, "http://159.89.38.11/-14"], "isController": false}, {"data": [0.025, 500, 1500, "http://159.89.38.11/-15"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 620, 55, 8.870967741935484, 3665.927419354837, 5, 19812, 2259.0, 8844.499999999998, 13828.199999999995, 18593.61999999998, 23.455529073506604, 2320.26550618545, 34.51381647703628], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["http://159.89.38.11/-21", 20, 1, 5.0, 2573.7999999999997, 966, 7268, 2271.5, 6776.900000000009, 7264.75, 7268.0, 1.7969451931716083, 7.390990004492362, 1.5307375898472595], "isController": false}, {"data": ["http://159.89.38.11/login/submit", 20, 20, 100.0, 1105.6999999999998, 611, 1903, 1090.0, 1629.2000000000003, 1890.1999999999998, 1903.0, 3.1852205765249244, 1.724187271062271, 1.486851011307533], "isController": false}, {"data": ["http://159.89.38.11/-22", 20, 3, 15.0, 2624.05, 5, 7769, 2462.0, 4277.000000000001, 7596.049999999997, 7769.0, 1.9567556990509736, 12.506516149349379, 1.4834271964582721], "isController": false}, {"data": ["http://159.89.38.11/-20", 20, 2, 10.0, 3379.05, 1406, 8310, 2876.5, 5525.400000000002, 8176.449999999998, 8310.0, 1.6014092401313156, 70.3792775142125, 1.303647209544399], "isController": false}, {"data": ["Test", 20, 20, 100.0, 19453.7, 16478, 21797, 19194.0, 21614.8, 21788.7, 21797.0, 0.75340917652377, 973.3996897484556, 16.39930450915392], "isController": true}, {"data": ["http://159.89.38.11/chart/data", 20, 20, 100.0, 999.2500000000001, 338, 1911, 1000.0, 1573.6000000000001, 1894.3999999999996, 1911.0, 2.1834061135371177, 1.1831758324235808, 2.068692003275109], "isController": false}, {"data": ["http://159.89.38.11/-5", 20, 0, 0.0, 1846.8, 760, 5249, 1489.5, 3461.000000000002, 5163.199999999999, 5249.0, 1.5804030027657052, 4.398582576056895, 1.468046226787831], "isController": false}, {"data": ["http://159.89.38.11/-6", 20, 0, 0.0, 2984.6000000000004, 1120, 5662, 2490.0, 5380.600000000002, 5652.3, 5662.0, 1.4892032762472078, 177.28499627699182, 0.5991716306775875], "isController": false}, {"data": ["http://159.89.38.11/-7", 20, 0, 0.0, 1169.05, 87, 6275, 822.5, 2587.300000000003, 6096.849999999998, 6275.0, 1.6389412439564042, 25.82989006289437, 0.6610182946816356], "isController": false}, {"data": ["http://159.89.38.11/-8", 20, 0, 0.0, 1521.9, 657, 3062, 1458.0, 2970.000000000002, 3061.6, 3062.0, 1.6, 37.3015625, 0.65], "isController": false}, {"data": ["http://159.89.38.11/-9", 20, 1, 5.0, 11508.600000000002, 5391, 17449, 12246.5, 15856.1, 17371.699999999997, 17449.0, 0.8728288382648163, 377.50316059505104, 1.5432619659378546], "isController": false}, {"data": ["http://159.89.38.11/-12", 20, 0, 0.0, 5066.3, 1650, 11233, 3664.0, 10927.800000000003, 11225.05, 11233.0, 1.2661433274246643, 109.321089991137, 1.1538720245631806], "isController": false}, {"data": ["http://159.89.38.11/-13", 20, 0, 0.0, 5068.35, 907, 13249, 3680.0, 9801.200000000003, 13082.499999999998, 13249.0, 1.1763321962122104, 50.729325961651575, 1.055941948006117], "isController": false}, {"data": ["http://159.89.38.11/-10", 20, 0, 0.0, 3084.85, 1057, 8122, 2418.5, 7247.200000000002, 8081.799999999999, 8122.0, 1.4534883720930232, 74.37488644622093, 2.511241824127907], "isController": false}, {"data": ["http://159.89.38.11/-0", 60, 0, 0.0, 4239.016666666666, 317, 15970, 2092.5, 11439.8, 14349.749999999998, 15970.0, 2.461437479488021, 373.23877417849525, 1.987658839637348], "isController": false}, {"data": ["http://159.89.38.11/-11", 20, 0, 0.0, 3407.15, 783, 7670, 2920.0, 7141.700000000003, 7650.599999999999, 7670.0, 1.3212657726101606, 54.64027507101803, 1.1912036731188478], "isController": false}, {"data": ["http://159.89.38.11/-1", 60, 1, 1.6666666666666667, 1414.316666666667, 341, 7304, 877.5, 3022.2999999999993, 6780.699999999998, 7304.0, 2.4433946896888745, 20.28375511585763, 1.765615137339143], "isController": false}, {"data": ["http://159.89.38.11/-2", 40, 0, 0.0, 937.2, 312, 6724, 454.5, 1481.3999999999999, 5192.249999999991, 6724.0, 2.6928773394371888, 24.538318803016026, 1.7530000336609668], "isController": false}, {"data": ["http://159.89.38.11/-3", 20, 0, 0.0, 3283.8500000000004, 595, 7989, 2389.0, 7296.3, 7955.299999999999, 7989.0, 1.536688436419516, 51.130906646177486, 1.4154341144832885], "isController": false}, {"data": ["http://159.89.38.11/-4", 20, 0, 0.0, 3375.7000000000003, 690, 8960, 2069.0, 7965.600000000002, 8914.699999999999, 8960.0, 1.4952153110047848, 24.16875373803828, 1.3494902250299043], "isController": false}, {"data": ["http://159.89.38.11/", 20, 4, 20.0, 17348.7, 13832, 19812, 17034.0, 19771.2, 19810.35, 19812.0, 0.8002560819462228, 1033.0587428602153, 16.2872431678137], "isController": false}, {"data": ["http://159.89.38.11/-18", 20, 2, 10.0, 3650.1500000000005, 44, 11225, 3066.5, 7382.7, 11033.099999999997, 11225.0, 1.440299582313121, 107.27826700453694, 1.188247155408325], "isController": false}, {"data": ["http://159.89.38.11/-19", 20, 0, 0.0, 2984.65, 1057, 7384, 2683.0, 6185.2000000000035, 7332.949999999999, 7384.0, 1.64866870002473, 32.72381965625257, 1.4767177067018382], "isController": false}, {"data": ["http://159.89.38.11/-16", 20, 0, 0.0, 3540.8, 931, 13834, 2610.5, 7140.700000000003, 13504.949999999995, 13834.0, 1.2990387113535984, 23.543808050792414, 1.2117595479345284], "isController": false}, {"data": ["http://159.89.38.11/-17", 20, 0, 0.0, 2826.7499999999995, 708, 7436, 2500.5, 6323.800000000001, 7382.049999999999, 7436.0, 1.3345789403443213, 31.762718120245562, 1.2344855198184972], "isController": false}, {"data": ["http://159.89.38.11/-14", 20, 0, 0.0, 6373.6, 2331, 14819, 4775.0, 14293.700000000004, 14802.35, 14819.0, 1.243858448908514, 183.67683585732942, 1.1226308383605945], "isController": false}, {"data": ["http://159.89.38.11/-15", 20, 1, 5.0, 5085.7, 1435, 11989, 3907.0, 9967.000000000002, 11892.3, 11989.0, 1.398308047262812, 102.55148887034188, 1.230688601167587], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 10, 18.181818181818183, 1.6129032258064515], "isController": false}, {"data": ["419/unknown status", 40, 72.72727272727273, 6.451612903225806], "isController": false}, {"data": ["Assertion failed", 5, 9.090909090909092, 0.8064516129032258], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 620, 55, "419/unknown status", 40, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 10, "Assertion failed", 5, "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["http://159.89.38.11/-21", 20, 1, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 1, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["http://159.89.38.11/login/submit", 20, 20, "419/unknown status", 20, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["http://159.89.38.11/-22", 20, 3, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 3, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["http://159.89.38.11/-20", 20, 2, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 2, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": ["http://159.89.38.11/chart/data", 20, 20, "419/unknown status", 20, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["http://159.89.38.11/-9", 20, 1, "Assertion failed", 1, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["http://159.89.38.11/-1", 60, 1, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 1, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["http://159.89.38.11/", 20, 4, "Assertion failed", 4, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["http://159.89.38.11/-18", 20, 2, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 2, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["http://159.89.38.11/-15", 20, 1, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 1, "", "", "", "", "", "", "", ""], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
